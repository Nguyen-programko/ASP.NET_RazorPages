﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace UserInfo.Controller
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private static readonly string[] Names =
        {
            "Pepa", "Petr", "Martin", "Bohumil", "Katerina", "Anna"
        };
        private string Username = "Admin";
        private string Password = "DGXJcuihdvhwefgi1284693";
        private readonly string jwtKey = "SADAJKGF{}:][[-0098()_&*^%$%E^%#@*$&!^%$)asdsadvaf321433y487JHASFGCHAG";

        private readonly ILogger<UserController> _ILogger;

        public UserController(ILogger<UserController> logger)
        {
            _ILogger = logger;
        }

        [AllowAnonymous]
        [HttpPost("Login")]
        public IActionResult Login([FromForm] string name, [FromForm] string password)
        {
            if (name == Username && password == Password)
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.UTF8.GetBytes(jwtKey);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, name) }),
                    Expires = DateTime.UtcNow.AddMinutes(5),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                var tokenString = tokenHandler.WriteToken(token);

                return Ok(new { token = tokenString });
            }
            return Unauthorized("Invalid credentials");
        }
        [Authorize]
        [HttpGet("Data")]
        public User GetUserData()
        {
            Random rnd = new Random();
            DateTime thisDay = DateTime.Today;
            return new User {Id = rnd.Next(100), Name = Names[rnd.Next(Names.Length)], Message = "I hope this is good", Date = thisDay };
        }
    }
}
    

