﻿namespace UserInfo 
{
    public class User
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public required string Message { get; set; }
        public DateTime Date { get; set; }
    }
}
