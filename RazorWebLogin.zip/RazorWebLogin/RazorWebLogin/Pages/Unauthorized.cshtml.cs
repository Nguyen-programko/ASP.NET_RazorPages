using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorWebLogin.Pages
{
    public class UnauthorizedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
