using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorWebLogin.Models;

namespace RazorWebLogin.Pages
{
    public class UzivatelModel : PageModel
    {
        private static readonly HttpClient client = new HttpClient();
        public User? UserData { get; set; }
        private string? JwtToken { get; set; }


        public async Task<IActionResult> OnGet()
        {
            await FetchUserData();
            if (UserData == null)
            {
                return RedirectToPage("/Unauthorized");
            }

            return Page();
        }


        public async Task FetchUserData()
        {
            JwtToken ??= Request.Cookies["JwtToken"];
            if (string.IsNullOrEmpty(JwtToken))
                return;

            var request = new HttpRequestMessage(HttpMethod.Get, "https://localhost:7090/User/Data");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", JwtToken);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                UserData = await response.Content.ReadFromJsonAsync<User>();
            }
        }

    }
}
