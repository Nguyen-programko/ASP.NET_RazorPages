using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace RazorWebLogin.Pages
{
    public class LoginPageModel : PageModel
    {
        private static readonly HttpClient client = new HttpClient();


        [BindProperty]
        public required string Name { get; set; }


        [BindProperty(Name = "pwd")]
        [DataType(DataType.Password)]
        public required string Password { get; set; }


        public void OnGet()
        {

        }
        public string? JwtToken { get; set; }
        public string? ErrorMessage { get; set; }
        public async Task<IActionResult> OnPostAsync()
        {
            var content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                { "name", Name },
                { "password", Password }
            });
            try
            {
                var response = await client.PostAsync("https://localhost:7090/User/Login", content);
                var responseString = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    
                    var json = System.Text.Json.JsonDocument.Parse(responseString);
                    JwtToken = json.RootElement.GetProperty("token").GetString();


                    Response.Cookies.Append("JwtToken", JwtToken, new CookieOptions
                    {
                        HttpOnly = true,
                        Secure = true,
                        Expires = DateTimeOffset.UtcNow.AddMinutes(5)
                    });

                    return Page();
                }
                else
                {
                    ErrorMessage = "Login failed: " + responseString;
                    return Page();
                }
            }
            catch
            {
                ErrorMessage = "Nemate pripojeni API";
                return Page();
            }
        }

    }
}
